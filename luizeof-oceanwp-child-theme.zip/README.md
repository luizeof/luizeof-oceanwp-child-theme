# powertic-oceanwp-child-theme
Child Theme for OceanWP
